﻿using BaiTap1.DATA;
using BaiTap1.DTOs;
using BaiTap1.DTOs.Student;
using BaiTap1.Mappers;
using Microsoft.EntityFrameworkCore;

namespace BaiTap1.Services
{
    public class StudentService : IStudentService
    {
        private readonly AppDBContext _appDbContext;

        public StudentService(AppDBContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public async Task<ApiResponse> GetAll()
        {
            ApiResponse response = new ApiResponse();
            var students = await _appDbContext.Students.ToListAsync();
            var studentDTOs = students.Select(student => StudentMapper.ToStudentDTO(student));
            if (students.Count > 0)
            {
                response.description = studentDTOs;
            }
            else
            {
                response.code = 1;
                response.description = "No student found.";
            }
            return response;
        }

        public async Task<ApiResponse> GetById(int id)
        {
            ApiResponse response = new ApiResponse();
            var student = _appDbContext.Students.Find(id);
            if (student != null)
            {
                response.description = StudentMapper.ToStudentDTO(student);
            }
            else
            {
                response.code = 1;
                response.description = "No Student found.";
            }
            return response;
        }


        public async Task<ApiResponse> CreateStudent(CreateStudentDTO create)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var student = StudentMapper.ToCreateStudentDTO(create);

                // Thêm course mới vào cơ sở dữ liệu
                _appDbContext.Students.Add(student);
                await _appDbContext.SaveChangesAsync();

                response.code = 0;
                response.description = "Student created successfully.";
            }
            catch (DbUpdateException dbEx)
            {
                // Đặc biệt xử lý lỗi liên quan đến cơ sở dữ liệu
                response.code = 1;
                response.description = $"Database error: {dbEx.Message}";
            }
            catch (Exception ex)
            {
                // Xử lý tất cả các loại lỗi khác
                response.code = 1;
                response.description = $"Error: {ex.Message}";
            }
            return response;
        }

        public async Task<ApiResponse> UpdateStudent(int id, UpdateStudentDTO update)
        {
            ApiResponse response = new ApiResponse();
            try
            {
                var student = _appDbContext.Students.Find(id);
                if (student == null)
                {
                    response.code = 1;
                    response.description = "Student not found.";

                }
                else
                {

                    student.EnrollmentDate = update.EnrollmentDate;
                    student.FirstMidName = update.FirstMidName;
                    student.LastName = update.LastName;
                    await _appDbContext.SaveChangesAsync();

                    response.code = 0;
                    response.description = "Student updated successfully.";
                }
            }
            catch (Exception e)
            {
                response.code = 1;
                response.description = $"Error: {e.Message}";
            }
            return response;
        }
        public async Task<ApiResponse> DeleteStudent(int id)
        {
            ApiResponse response = new ApiResponse();
            var student = _appDbContext.Students.Find(id);
            if (student != null)
            {
                try
                {
                    _appDbContext.Remove(student);
                   await _appDbContext.SaveChangesAsync();
                    response.code = 0;
                    response.description = "Delete student successfully.";
                }
                catch (Exception ex)
                {
                    response.code = 1;
                    response.description = $"Error: {ex.Message}";
                }
            }
            else
            {
                response.code = 1;
                response.description = "No student found.";
            }
            return response;
        }
    }
}
